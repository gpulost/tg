import os
import sys
import json
from telethon.sync import TelegramClient
from telethon.sessions import StringSession
from telethon.tl.functions.contacts import ImportContactsRequest, DeleteContactsRequest
from telethon.tl.types import InputPhoneContact
from dotenv import load_dotenv, find_dotenv

# 加载环境变量
_ = load_dotenv(find_dotenv())

def get_session_string(app_id, app_hash, session_file):
    """
    从SQLite session文件获取StringSession

    Args:
        app_id: Telegram API ID
        app_hash: Telegram API Hash
        session_file: SQLite session文件名(不含.session后缀)

    Returns:
        str: session字符串, 失败返回None
    """
    # 使用 SQLite 文件中的 session 初始化客户端
    client = TelegramClient(session_file, app_id, app_hash)

    try:
        # 连接并确认会话可用
        client.connect()
        if not client.is_user_authorized():
            print("Session 失效，需要重新登录。")
            return None

        # 将当前 session 转换为 StringSession
        session_string = StringSession.save(client.session)
        print("成功获取 StringSession：")
        print(session_string)
        return session_string

    except Exception as e:
        print(f"获取session失败: {str(e)}")
        return None

    finally:
        client.disconnect()


def check_phone_number(app_id, app_hash, session_string, phone_number):
    """
    检测电话号码是否注册 Telegram

    Args:
        app_id: Telegram API ID
        app_hash: Telegram API Hash
        session_string: StringSession 字符串
        phone_number: 待检测的电话号码 (格式: +1234567890)

    Returns:
        bool: True 表示已注册 Telegram, False 表示未注册或失败
    """
    # 使用 StringSession 初始化客户端
    client = TelegramClient(StringSession(session_string), app_id, app_hash)

    try:
        # 连接客户端
        client.connect()
        if not client.is_user_authorized():
            print("用户未授权，请检查 StringSession 有效性。")
            return False

        # 创建 InputPhoneContact 对象
        contact = InputPhoneContact(
            client_id=0,  # 可以是任意整数
            phone=phone_number,
            first_name="Test",
            last_name=""
        )

        # 添加电话号码为联系人
        result = client(ImportContactsRequest([contact]))
        print(result)

        if result.users:
            print(f"号码 {phone_number} 是有效的 Telegram 用户。")
            # 删除联系人（清理临时联系人）
            if result.users:
                client(DeleteContactsRequest(result.users))
            return True
        else:
            print(f"号码 {phone_number} 未注册 Telegram。")
            return False

    except Exception as e:
        print(f"检测失败: {str(e)}")
        return False

    finally:
        client.disconnect()


# 主函数
if __name__ == "__main__":
    # 从环境变量中读取 API 配置
    dir_path = "./"
    for file in os.listdir(dir_path):
        if not file.endswith('.json'):
            continue
        json_path = os.path.join(dir_path, file)
        session_file = json_path.replace('.json', '')
        with open(json_path, 'r') as f:
            data = json.load(f)
        country_code = data['phone'][:2]
        phone_number = data['phone']
        app_id = str(data['app_id'])
        app_hash = data['app_hash']
        session = get_session_string(app_id, app_hash, session_file)
        print(phone_number, app_id, app_hash, session)

        if not app_id or not app_hash or not session:
            print("请设置 SESSION、TELEGRAM_API_ID 和 TELEGRAM_API_HASH 环境变量")
            sys.exit(1)

        phone_to_check = "+8615710086955"  # 替换为实际需要检测的号码
        # 检测电话号码是否注册 Telegram
        is_registered = check_phone_number(app_id, app_hash, session, phone_to_check)

        if is_registered:
            print(f"号码 {phone_to_check} 已注册 Telegram。")
        else:
            print(f"号码 {phone_to_check} 未注册 Telegram。")
